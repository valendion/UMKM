package com.usaha.umkm.data.model

data class ModelResponseDetailCategory(
    val image: Int? = null,
    val textDescription: String? = null,
    val rate: Int? = null,
    val title: String? = null
)
